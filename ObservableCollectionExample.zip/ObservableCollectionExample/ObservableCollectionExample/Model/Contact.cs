﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObservableCollectionExample.Model
{
    class Contact
    {
        public string FirtName { get; set; }
        public string LastName { get; set; }
        public string AvataPath { get; set; }

    }
}
